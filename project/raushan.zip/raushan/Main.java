package bit.raushan;

//public class Main {
//    public static void main(String[] args) {
//        User[] memory = new User[1000];
////        chooser(memory);
//    }
//
//    static void chooser(User[] memory) {
//        Scanner scanner = new Scanner(System.in);
//
//        while (true) {
//            System.out.println("PRESS [1] TO ADD USER");
//            System.out.println("PRESS [2] TO LIST USERS");
//            System.out.println("PRESS [3] TO LIST USER BY INDEX");
//            System.out.println("PRESS [0] TO EXIT");
//            String choice = scanner.next();
//            if (choice.equals("1")) {
//                System.out.println("PRESS [1] TO ADD STUDENT");
//                System.out.println("PRESS [2] TO ADD TEACHER");
//                String choice1 = scanner.next();
//
//                if (choice1.equals("1")) {
//                    System.out.println("Login: ");
//                    String login = scanner.next();
//                    System.out.println("Password: ");
//                    String password = scanner.next();
//                    System.out.println("Name: ");
//                    String name = scanner.next();
//                    System.out.println("Surname: ");
//                    String surname = scanner.next();
//                    System.out.println("Group: ");
//                    String group = scanner.next();
//                    System.out.println("GPA: ");
//                    String GPA = scanner.next();
//                    Student student = new Student(login, password,name,surname,group,double gpa);
//
//
//                } else if (choice1.equals("2")) {
//                    System.out.println("Login");
//                    String Login = scanner.next();
//                    System.out.println("Password: ");
//                    String Password = scanner.next();
//                    System.out.println("Nick Name: ");
//                    String NickName = scanner.next();
//                    System.out.println("Status: ");
//                    String Status = scanner.next();
//                }
//
//
//            }
//            if (choice.equals("2")) {
//                for (int i = 0; i < memory.length; i++) {
//                    System.out.println(memory[i]);
//
//                }
//
//
//            }
//            if (choice.equals("3")) {
//                for (int i = 0; i < ; i++) {
//
//                }
//
//            }
//
//            if (choice.equals("0")) {
//                System.out.println("Exit");
//
//            }
//
//        }
//
//
//    }
//
//
////    public static void main(String[] args) {
////        FerrariEngine ferrariEngine = new FerrariEngine(10000,23,34);
////        RenaultEnigine renaultEnigine = new RenaultEnigine (10000, 23, 34, 3);
////        Engine [] engines = {ferrariEngine, renaultEnigine};
////        for (int i = 0; i < engines.length; i++) {
////            System.out.println(engines[i].getMaxSpeed());
////
////        }
////
////    }

//}

