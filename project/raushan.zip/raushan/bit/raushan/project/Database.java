package bit.raushan.project;

public class Database {
    public static BankAccount bankAccounts[] = new BankAccount[5];
    static{
        bankAccounts[0] = new CityBankAccount("Ilyas","Zhuanyshev",20000,"KZ010322312","0102" );
        bankAccounts[1] = new CityBankAccount("Erbol","Zhuanyshev",20000,"KZ010322312 ", "0102");
        bankAccounts[2] = new NationalBankAccount("Ilyas Zhuanyshev", 2000,"KZ0101112", "0102");

    }

}
