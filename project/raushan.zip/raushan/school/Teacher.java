package bit.raushan.school;

public abstract class Teacher extends User{

    private String nickName;
    private String status;
    private int sizeOfSubjects = 0;
    String subjects[] = new String[10];



    public Teacher(int id, String login, String password) {
        super(id, login, password);
    }

    public Teacher(String nickName, String status, int sizeOfSubjects, String[] subjects) {
        this.nickName = nickName;
        this.status = status;
        this.sizeOfSubjects = sizeOfSubjects;
        this.subjects = subjects;
    }

    public Teacher(int id, String login, String password, String nickName, String status, int sizeOfSubjects, String[] subjects) {
        super(id, login, password);
        this.nickName = nickName;
        this.status = status;
        this.sizeOfSubjects = sizeOfSubjects;
        this.subjects = subjects;
    }

    public  void addSubject(String subject){
        subjects[sizeOfSubjects]=subject;
        sizeOfSubjects++;

    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getSizeOfSubjects() {
        return sizeOfSubjects;
    }

    public String[] getSubjects() {
        return subjects;
    }

    @Override
    protected String getUserData() {
        return getNickName() + getStatus() + getSubjects().toString();
    }
}
