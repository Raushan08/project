package bit.raushan.school;

public abstract class Student extends User {
    private String name;
    private String surname;
    private String group;
    private double gpa;

    public Student(int id, String login, String password, String name, String surname, String group, double gpa) {
        super(id, login, password);
        this.name = name;
        this.surname = surname;
        this.group = group;
        this.gpa = gpa;
    }

    public Student(String name, String surname, String group, double gpa) {
        this.name = name;
        this.surname = surname;
        this.group = group;
        this.gpa = gpa;
    }

    public Student(int id, String login, String password) {
        super(id, login, password);

    }

    @Override
    protected String getUserData() {
        return name + " " + surname + " " + group + " " + gpa;
    }
}
