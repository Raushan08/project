package bit.raushan.school;

public class ERPSystem {
    private User []memory = new User[1000];
    private int sizeOfUsers = 0;

    void addUser(User u) {
        memory [sizeOfUsers]=u;
        sizeOfUsers++;

    }
    void printAllUsers(){
        for (User u: memory){
        System.out.println(u.getUserData());

        }


    }

    void printUser(int index){
        for (int i = 0; i < memory.length; i++) {
            if (index==i) System.out.println(memory[i].getUserData());
            else System.out.println("no user with such id");

        }
    }


}
