package bit.raushan.practiceOne;

public interface UserBean {
    void getAlUsers();
    void getUsersByName(String name);
    void getUsersBySurname(String surname);

}
