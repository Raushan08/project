package bit.raushan.practiceOne;

import bit.raushan.practice2.HRManagers;
import bit.raushan.practice2.Programmers;
import bit.raushan.practice2.Staff;
import bit.raushan.practice2.Workers;

public class Main {
    public static void main(String[]args) {
//        Users users1 = new Users("one", "two");
//        Users users2 = new Users("one", "two");
//        Users[] users = {users1, users2};
//        UserBeanImp userBeanImp = new UserBeanImp(users);
//        userBeanImp.getAlUsers();
//        userBeanImp.getUsersByName(" ");
//        userBeanImp.getUsersBySurname(" ");

        Programmers programmers = new Programmers ("AA", 100,10, 1.1 );
        HRManagers hrManagers =  new HRManagers(12, "BB", 1000);
        Staff staff = new Staff(12, "CC", "CCC", 10000);
//        System.out.println(programmers.getSalary());
//        System.out.println(hrManagers.getSalary());
//        System.out.println(staff.getSalary());


        Workers [] workers = {programmers, staff, hrManagers};
        int max = workers[0].getSalary();

        for (Workers w: workers) {
            if (max< w.getSalary()){
                max = w.getSalary();
            }


        }
        System.out.println(max);

    }
}
