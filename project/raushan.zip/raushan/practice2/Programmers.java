package bit.raushan.practice2;

public class Programmers implements Workers{
    int id;
    String nickname;
    int salary;
    int bonusSalary;
    double KPIValue;

    public Programmers(int id, String nickname, int salary, int bonusSalary, double KPIValue) {
        this.id = id;
        this.nickname = nickname;
        this.salary = salary;
        this.bonusSalary = bonusSalary;
        this.KPIValue = KPIValue;
    }

    public Programmers(String nickname, int salary, int bonusSalary, double KPIValue) {
        this.nickname = nickname;
        this.salary = salary;
        this.bonusSalary = bonusSalary;
        this.KPIValue = KPIValue;
    }

    @Override
    public String getWorkerData() {
        return nickname;
    }

    @Override
    public int getSalary() {
        return (int) (salary + KPIValue*bonusSalary);
    }
}
