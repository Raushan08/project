package bit.raushan.practice2;

public interface Workers {
    String getWorkerData();

    int getSalary();
}
