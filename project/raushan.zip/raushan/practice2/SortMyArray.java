package bit.raushan.practice2;

public class SortMyArray {
    public void sortArray (Workers [] workers){
        while (true){
            for (int i = 0; i < workers.length; i++) {
                if (workers[i+1].getSalary()>workers[i].getSalary()){

                }

            }
        }
    }
}
